<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

 Operators in PHP
1. Arithmetic Operators
2. Assignment Operators
3. Comparison Operators 
4. Logical Operators
<br>
<h1>1. Arithmetic Operators</h1>
    <?php

    $a =45;
    $b = 8;
    //Airthematic operators
    echo "for a+b,the result is" . ($a+$b);
    echo "<br>";
    echo "for a-b,the result is" . ($a-$b);
    echo "<br>";
    echo "for a*b,the result is" . ($a*$b);
    echo "<br>";
    echo "for a/b,the result is" . ($a/$b);
    echo "<br>";
    echo "for a%b,the result is" . ($a%$b);
    echo "<br>";
    echo "for a**b,the result is" . ($a**$b);

    ?>

<h1>2. Assignment Operators</h1>

<?php
//assigned a value in a
$x = $a;
echo "For x, the value is ". $x . "<br>" ;
//echo "For x, the value is ". $x . "<br>";

$a += 6;
echo "For a, the value is ". $a . "<br>" ;
$a -= 6;
echo "For a, the value is ". $a . "<br>" ;
$a *= 6;
echo "For a, the value is ". $a . "<br>" ;
$a /= 6;
echo "For a, the value is ". $a . "<br>" ;
$a %= 5;
echo "For a, the value is ". $a . "<br>" ;

?>

<h1>3. Comparison Operators</h1>
<?php
$x = 7;
$y = 9;

//echo " For x==y " . var_dump($x == $y) . "<br>";

echo "For x == y, the result is "; 
echo var_dump($x == $y);
echo "<br>";

echo "For x > y, the result is "; 
echo var_dump($x > $y);
echo "<br>";

echo "For x < y, the result is "; 
echo var_dump($x < $y);
echo "<br>";

echo "For x >= y, the result is "; 
echo var_dump($x >= $y);
echo "<br>";

echo "For x <= y, the result is "; 
echo var_dump($x <= $y);
echo "<br>";


//Not equal
echo "For x <> y, the result is "; 
echo var_dump($x <> $y);
echo "<br>";

//!==
echo "For x !== y, the result is "; 
echo var_dump($x !== $y);
echo "<br>";

?>
<h1>4.Logical Operators</h1>


<?php
$m = false;
$n = false;
//echo var_dump($m == $n);
//echo var_dump($x !== $y);

//and &&

echo var_dump($m && $n);
echo "<br>";

//or ||

echo var_dump($m || $n);
echo "<br>";
//!
echo var_dump(! $m );


?>


    </body>
</html>