<?php

$age = 10;

switch($age){

case 12:
echo "you are 12 years old <br>";
break;

case 22:
    echo "you are 22 years old <br>";
    break;

case 30:
    echo "you are 30 years old <br>";
    break;
default:
echo "you are dead <br>";
break;
}
?>