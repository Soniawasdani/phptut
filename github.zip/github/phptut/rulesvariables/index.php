<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>More on variables</h1>
    
    <h5>Rules for creating variables</h5>
    <ol>
        <li>starts with $</li>
        <li>can not start with a number</li>
        <li>Must start with a letter or underscore character</li>
        <li>can only contain alphanumeric charcters and undercore 
            <!-- alpha numeric characters A to Z, and the 10 Arabic numerals, 0 to 9. -->
        </li>
<li>
<?php $name = "sonia"; echo "$name <br>"; ?>
    <?php $name5 = "sonia"; echo "$name5"; ?>
    <?php // $name& = "sonia"; echo "$name&"; //
 //& % can not use in variable
 ?>
</li>
<li>Variables in php are case sensitve($sonia $sOnia $Sonia are differnt )</li>
<?php
$sonia = "sonia";
$sOnia = "honey";
$Sonia = "aju";

echo "$sonia";
echo "$sOnia";
echo "$Sonia";
?>
    </ol>
    


 

</body>
</html>