<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <!-- echo is not case sensitive -->

<?PHP
/*
ECHO "HELLO THIS IS NOT CASE SENSITIVE"*/

//Variables are container for storing information
//variables are case sensitive
//start with a $

$name = "sonia";
$income = 55000;
$country = "Australia";
//you have to put invert commas for echo anything 
//echo  "This girls is $name and her income is $income";



echo "my name is $name <br>";
echo "I live in $country <br>";
echo "$country is beautiful country  <br>";
echo "my income is $income <br>";
echo "$name is new in this $country";

//let suppose we write same line for other person we have to change only name in variable this nis the benifit 


?>

</body>
</html>