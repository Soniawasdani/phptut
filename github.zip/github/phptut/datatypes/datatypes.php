<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
  
<h1>Data types in php</h1>
<!-- data types -->
<ol>
<li>String</li>
<li>Integer</li>
<li>Float</li>
<li>Bollean</li>
<li>Object</li>
<li>Array</li>
<li>Null</li>
</ol>

<h2>1  String - sequence of characters</h2>
 <?php
$name = "sonia";
//we can also put one qumoa for varaible 
$frnd ='mashu';
echo "$name ki frnd is $frnd ";
 ?>

<h2>2  Integer - is non decimal number</h2>
<?php
$income = 15000;
$debts = -200;

echo "income $income <br> debt $debts";
echo "<br>";
?>



<h2>3 Float - Decimal point number</h2>
<?php
$income = 450.5;
$debts = -800.5;

echo "income $income <br> debt $debts";

?>

<h2>4 Boolean - can be true or false</h2>
<?php
$X = true;
$is_frnd = false;
//ek variable echo karna hai to "" ki zarorat nhe

echo $X;
echo "<br>";
echo $is_frnd;
echo "<br>";
 //vardump define datatypes

 echo var_dump ($X);
 echo "<br>";
 echo var_dump ($is_frnd);
?>

<h2>5 Object - Instances of Classes</h2>
<p>ek template se instances banate ho <br> will learn later in detail </p>

<h2>6 Array - use to store multiple values in single variable</h2>
<?php
$frndlst = array("aju","honey","avi","mashu");
//replace array value using array number
$frndlst[03] = "charlie";
//add array value using array number

$frndlst[04] = "mashu";
echo var_dump($frndlst);
echo "<br>";
echo ($frndlst[0]);
echo "<br>";
echo ($frndlst[1]);
echo "<br>";
echo ($frndlst[2]);
echo "<br>";
echo ($frndlst[3]);
echo "<br>";
echo count($frndlst);

?>

<h2>7 Null = No Value</h2>
<?php
$name = null;
echo var_dump($name);
?>

</body>
</html>