<?php

echo "Associate array"



?>