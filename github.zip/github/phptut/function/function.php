<?php
/*
function sayhi(){


    echo "hello user <br>";
}
sayhi()

?>


<?php

function greet($name){


    echo $name;
}
greet("sonia <br>");
greet("sia <br>");
greet("sonavi <br> ");

?>


<?php

function cube($num){


    return $num * $num;
}
echo cube(8);
*/
?>

<?php

function result($student){
$sum = 0;

foreach ($student as  $value) {
    $sum += $value;
}
return $sum;
}
$sonia = [38,48,55,68];
$summarks = result($sonia);
echo $summarks;

?>