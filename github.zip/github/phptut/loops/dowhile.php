<?php


$i = 80;
do{
    echo "$i  <br>";
    $i++;
}while($i<5);

?>