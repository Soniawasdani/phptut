<?php


for ($i=0; $i <= 28; $i+=2) {
    
    //intialiaze condition updation

    echo "the table of 2 is ";
    echo $i+2 ;
    echo "<br>";

}


?>