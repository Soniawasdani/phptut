<?php

echo "while loops <br>";

$i = 0;

while($i < 5){
    echo $i+1 ;
    echo "<br>";
 $i++;
 
}

?>
<br>
<?php

$j = 0;

while($j < 20){
    echo $j+2 ; //shuru kahan se karen ga jaise 1 2 ya kahin se bhi q k variable 0 hai 
    echo "<br>";
 $j+=2;
 
}

?>
<br>

<?php

$j = 0;
$m = 1;

while($j < 190){
  echo  "19 * "; echo $m++  ; echo " = ";
    echo $j+19 ; //shuru kahan se karen ga jaise 1 2 ya kahin se bhi q k variable 0 hai 
    echo "<br>";
 $j+=19;
 
}

?>