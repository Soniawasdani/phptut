<?php

$grocery = array("Bread","Eggs", "Milk", "Sauces","Vegetables","spices");
    
    foreach($grocery as $value)
    {
        echo $value;
        echo " <br> ";

    }


    for ($i=0;  $i< count($grocery); $i++) {
    
        //intialiaze condition updation
    
        
        echo $grocery[$i];
        echo "<br>";
    
    }


    ?>