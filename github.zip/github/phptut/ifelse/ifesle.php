<?php
echo "Exampl 1 <br> ";
$a = 18;
$b = 16;

if ($a >= $b){
echo "yes you are right <br> ";
 }
else
{echo " you are wrong <br> ";
}

echo "Exampl 2 <br> ";
$age = 15;

if ($age >= 18){
echo "you can drink beer";
}


elseif ($age >= 13)
{
    echo "oops you are under age <br>";
}

else {

    echo "you can drink water <br>";
}

echo "Exampl 3 <br> ";
$drivage = 4;

if($drivage >= 25){

    echo "you can drive <br>";

}

elseif ($drivage <= 65 &&  $drivage  >= 25)

{

    echo "you can also drive <br>";

}

else if ($drivage >= 18){
    echo "you are valid for drive training <br>";

}
else 
{
    echo "you are not allowed <br> ";

}




?>